import { useState, useEffect } from "react";
import Calendar from "../components/Calendar";
import axios from "axios";

export default function Home() {
  const [tasks, setTasks] = useState([]);

  const reload = () => axios.get("/api/tasks").then(r => setTasks(r.data));
  useEffect(reload, []);

  const scheduleOne = (id, date) => {
    axios.patch("/api/tasks", { id, date }).then(() => reload());
  };

  const autoPlan = () => {
    axios.post("/api/suggest").then(() => reload());
  };

  return (
    <div style={{ display: "flex" }}>
      <aside style={{ width: 300, padding: 16, borderRight: "1px solid #ddd" }}>
        <h2>Unscheduled</h2>
        {tasks.map(t => (
          <div key={t.id} draggable
               onDragStart={e => e.dataTransfer.setData("text/plain", t.id)}>
            {t.properties.Name.title[0].plain_text}
          </div>
        ))}
        <button onClick={autoPlan}>Auto-Plan</button>
      </aside>

      <main style={{ flex: 1, padding: 16 }}>
        <Calendar onEventDrop={scheduleOne} />
      </main>
    </div>
  );
}
