import { notion } from "../../lib/notion";

export default async function handler(req, res) {
  const { method, query, body } = req;

  if (method === "GET") {
    const statusFilter = query.status || "Unscheduled";
    const response = await notion.databases.query({
      database_id: process.env.NOTION_DATABASE_ID,
      filter: { property: "Status", select: { equals: statusFilter } }
    });
    res.status(200).json(response.results);
  } else if (method === "PATCH") {
    const { id, date } = body;
    await notion.pages.update({
      page_id: id,
      properties: {
        Date: { date: { start: date } },
        Status: { select: { name: "Scheduled" } }
      }
    });
    res.status(200).json({ success: true });
  } else {
    res.setHeader("Allow", ["GET", "PATCH"]);
    res.status(405).end();
  }
}
