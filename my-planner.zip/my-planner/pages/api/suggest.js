import { openai } from "../../lib/openai";
import { notion } from "../../lib/notion";

export default async function handler(req, res) {
  // 1. fetch unscheduled tasks
  const db = await notion.databases.query({
    database_id: process.env.NOTION_DATABASE_ID,
    filter: { property: "Status", select: { equals: "Unscheduled" } }
  });
  const tasks = db.results.map(p => ({
    id: p.id,
    name: p.properties.Name.title[0].plain_text,
    duration: p.properties.Duration.number
  }));

  // 2. prompt ChatGPT
  const prompt = `
You have work hours from 9 AM to 5 PM on weekdays.
Here are tasks in JSON: ${JSON.stringify(tasks)}.
Schedule them in the next available slots, returning JSON array:
[{"id":"...","date":"2025-05-08T09:00:00"},...]
`;
  const chat = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }]
  });
  const plan = JSON.parse(chat.choices[0].message.content);

  // 3. push dates back to Notion
  await Promise.all(plan.map(item =>
    notion.pages.update({
      page_id: item.id,
      properties: {
        Date: { date: { start: item.date } },
        Status: { select: { name: "Scheduled" } }
      }
    })
  ));

  res.status(200).json({ scheduled: plan });
}
