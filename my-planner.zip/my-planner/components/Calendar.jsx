import { useEffect, useState } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import axios from "axios";

export default function Calendar({ onEventDrop }) {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    axios.get("/api/tasks?status=Scheduled")
      .then(r => {
        const evs = r.data.map(p => ({
          id: p.id,
          title: p.properties.Name.title[0].plain_text,
          start: p.properties.Date.date.start
        }));
        setEvents(evs);
      });
  }, []);

  return (
    <FullCalendar
      plugins={[dayGridPlugin, interactionPlugin]}
      initialView="dayGridWeek"
      editable
      events={events}
      eventDrop={e => {
        onEventDrop(e.event.id, e.event.start.toISOString());
      }}
    />
  );
}
